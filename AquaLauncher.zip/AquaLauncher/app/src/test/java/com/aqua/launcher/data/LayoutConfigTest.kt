package com.aqua.launcher.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LayoutConfigTest {
    @Test fun firstFreeSlot_homeStartsAtOrigin() {
        assertEquals(Slot(0, 0, 0), LayoutConfig.firstFreeSlot(LayoutConfig.HOME, emptySet()))
    }

    @Test fun firstFreeSlot_skipsOccupied() {
        val taken = setOf(Slot(0, 0, 0), Slot(0, 0, 1))
        assertEquals(Slot(0, 0, 2), LayoutConfig.firstFreeSlot(LayoutConfig.HOME, taken))
    }

    @Test fun firstFreeSlot_overflowsToNextPage() {
        val page0 = (0 until LayoutConfig.ROWS).flatMap { r ->
            (0 until LayoutConfig.COLUMNS).map { c -> Slot(0, r, c) }
        }.toSet()
        assertEquals(Slot(1, 0, 0), LayoutConfig.firstFreeSlot(LayoutConfig.HOME, page0))
    }

    @Test fun firstFreeSlot_dockFullReturnsNull() {
        val full = (0 until LayoutConfig.DOCK_SLOTS).map { Slot(0, 0, it) }.toSet()
        assertNull(LayoutConfig.firstFreeSlot(LayoutConfig.DOCK, full))
    }
}
