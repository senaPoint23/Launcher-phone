package com.aqua.launcher.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aqua.launcher.data.AppInfo
import com.aqua.launcher.data.LayoutConfig

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(vm: HomeViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val homeSignal by vm.homeSignal.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val pager = rememberPagerState(pageCount = { LayoutConfig.PAGES })
    var showDrawer by remember { mutableStateOf(false) }

    LaunchedEffect(homeSignal) {
        showDrawer = false
        pager.animateScrollToPage(0)
    }
    LaunchedEffect(Unit) {
        vm.messages.collect { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
    }
    BackHandler(showDrawer) { showDrawer = false }

    Box(Modifier.fillMaxSize().systemBarsPadding()) {
        Column(
            Modifier.fillMaxSize().pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -120f) showDrawer = true },
                    onVerticalDrag = { _, delta -> total += delta },
                )
            },
        ) {
            HorizontalPager(pager, Modifier.weight(1f)) { page ->
                PageGrid(
                    items = state.items.filter {
                        it.entity.container == LayoutConfig.HOME && it.entity.page == page
                    },
                    onLaunch = vm::launch,
                    onUnpin = vm::unpin,
                    onInfo = vm::showInfo,
                )
            }
            PageIndicator(pager.currentPage, LayoutConfig.PAGES)
            Dock(
                items = state.items.filter { it.entity.container == LayoutConfig.DOCK },
                onLaunch = vm::launch,
                onUnpin = vm::unpin,
                onInfo = vm::showInfo,
                onOpenDrawer = { showDrawer = true },
            )
        }

        AnimatedVisibility(
            visible = showDrawer,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            AppDrawer(
                apps = state.apps,
                onLaunch = { vm.launch(it); showDrawer = false },
                onPinHome = { vm.pin(it, LayoutConfig.HOME) },
                onPinDock = { vm.pin(it, LayoutConfig.DOCK) },
                onInfo = vm::showInfo,
            )
        }
    }
}

@Composable
private fun PageGrid(
    items: List<HomeItem>,
    onLaunch: (AppInfo) -> Unit,
    onUnpin: (Long) -> Unit,
    onInfo: (AppInfo) -> Unit,
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
        repeat(LayoutConfig.ROWS) { r ->
            Row(Modifier.weight(1f).fillMaxWidth()) {
                repeat(LayoutConfig.COLUMNS) { c ->
                    Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                        items.firstOrNull { it.entity.row == r && it.entity.col == c }?.let { item ->
                            AppIcon(item.app, Color.White, { onLaunch(item.app) }) { dismiss ->
                                DropdownMenuItem(
                                    text = { Text("Lepas dari Home") },
                                    onClick = { dismiss(); onUnpin(item.entity.id) },
                                )
                                DropdownMenuItem(
                                    text = { Text("Info aplikasi") },
                                    onClick = { dismiss(); onInfo(item.app) },
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PageIndicator(current: Int, count: Int) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
    ) {
        repeat(count) { i ->
            Box(
                Modifier.padding(horizontal = 3.dp).size(if (i == current) 8.dp else 6.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = if (i == current) 0.95f else 0.45f)),
            )
        }
    }
}

@Composable
private fun Dock(
    items: List<HomeItem>,
    onLaunch: (AppInfo) -> Unit,
    onUnpin: (Long) -> Unit,
    onInfo: (AppInfo) -> Unit,
    onOpenDrawer: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Color.Black.copy(alpha = 0.28f))
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(LayoutConfig.DOCK_SLOTS) { c ->
            Box(Modifier.weight(1f).height(80.dp), contentAlignment = Alignment.Center) {
                items.firstOrNull { it.entity.col == c }?.let { item ->
                    AppIcon(item.app, Color.White, { onLaunch(item.app) }) { dismiss ->
                        DropdownMenuItem(
                            text = { Text("Lepas dari Dock") },
                            onClick = { dismiss(); onUnpin(item.entity.id) },
                        )
                        DropdownMenuItem(
                            text = { Text("Info aplikasi") },
                            onClick = { dismiss(); onInfo(item.app) },
                        )
                    }
                }
            }
        }
        Box(Modifier.weight(1f).height(80.dp), contentAlignment = Alignment.Center) {
            IconButton(onClick = onOpenDrawer) {
                Icon(Icons.Default.Menu, contentDescription = "Buka daftar aplikasi", tint = Color.White)
            }
        }
    }
}

@Composable
private fun AppDrawer(
    apps: List<AppInfo>,
    onLaunch: (AppInfo) -> Unit,
    onPinHome: (AppInfo) -> Unit,
    onPinDock: (AppInfo) -> Unit,
    onInfo: (AppInfo) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }
    Surface(
        Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background.copy(alpha = 0.97f),
    ) {
        Column(Modifier.padding(16.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Cari aplikasi") },
                singleLine = true,
                shape = RoundedCornerShape(24.dp),
            )
            Spacer(Modifier.height(12.dp))
            if (filtered.isEmpty()) {
                Text("Tidak ada aplikasi yang cocok", color = MaterialTheme.colorScheme.onBackground)
            }
            LazyVerticalGrid(GridCells.Adaptive(80.dp), Modifier.fillMaxSize()) {
                items(filtered, key = { it.key }) { app ->
                    AppIcon(app, MaterialTheme.colorScheme.onBackground, { onLaunch(app) }) { dismiss ->
                        DropdownMenuItem(
                            text = { Text("Pasang di Home") },
                            onClick = { dismiss(); onPinHome(app) },
                        )
                        DropdownMenuItem(
                            text = { Text("Pasang di Dock") },
                            onClick = { dismiss(); onPinDock(app) },
                        )
                        DropdownMenuItem(
                            text = { Text("Info aplikasi") },
                            onClick = { dismiss(); onInfo(app) },
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppIcon(
    app: AppInfo,
    labelColor: Color,
    onClick: () -> Unit,
    menu: @Composable (dismiss: () -> Unit) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        Column(
            Modifier.clip(RoundedCornerShape(16.dp))
                .combinedClickable(onClick = onClick, onLongClick = { expanded = true })
                .padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(56.dp))
            Text(
                text = app.label,
                color = labelColor,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = LocalTextStyle.current.copy(
                    shadow = if (labelColor == Color.White) {
                        Shadow(Color.Black.copy(alpha = 0.5f), blurRadius = 4f)
                    } else null,
                ),
            )
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            menu { expanded = false }
        }
    }
}
