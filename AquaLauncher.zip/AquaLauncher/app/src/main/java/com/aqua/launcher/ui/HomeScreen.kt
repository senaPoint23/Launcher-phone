package com.aqua.launcher.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.changedToUp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aqua.launcher.data.AppInfo
import com.aqua.launcher.data.LayoutConfig
import com.aqua.launcher.data.Slot
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull

/** Callback drag; semua posisi dalam koordinat root layar. */
class DragHandler(
    val start: (Offset) -> Unit,
    val move: (Offset) -> Unit,
    val end: (moved: Boolean, canceled: Boolean) -> Unit,
)

private data class DragUi(val item: HomeItem, val pos: Offset)

private const val TAP = 0
private const val CANCEL = 1

@Composable
fun HomeScreen(vm: HomeViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val homeSignal by vm.homeSignal.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val pager = rememberPagerState(pageCount = { LayoutConfig.PAGES })
    var showDrawer by remember { mutableStateOf(false) }
    var drag by remember { mutableStateOf<DragUi?>(null) }
    var rootOrigin by remember { mutableStateOf(Offset.Zero) }
    var screenWidth by remember { mutableStateOf(0f) }
    val homeBounds = remember { mutableMapOf<Slot, Rect>() }
    val dockBounds = remember { mutableMapOf<Slot, Rect>() }

    LaunchedEffect(homeSignal) {
        showDrawer = false
        drag = null
        pager.animateScrollToPage(0)
    }
    LaunchedEffect(Unit) {
        vm.messages.collect { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
    }
    BackHandler(showDrawer) { showDrawer = false }

    val hit: (Offset) -> Pair<String, Slot>? = { pos ->
        val dock = dockBounds.entries.firstOrNull { it.value.contains(pos) }
        if (dock != null) {
            LayoutConfig.DOCK to dock.key
        } else {
            homeBounds.entries.firstOrNull { it.value.contains(pos) }?.let {
                LayoutConfig.HOME to Slot(pager.currentPage, it.key.row, it.key.col)
            }
        }
    }
    val hover = drag?.let { hit(it.pos) }

    val dragFor: (HomeItem) -> DragHandler = { item ->
        DragHandler(
            start = { pos ->
                drag = DragUi(item, pos)
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            },
            move = { pos -> drag = drag?.copy(pos = pos) },
            end = { moved, canceled ->
                val d = drag
                drag = null
                if (d != null && moved && !canceled) {
                    hit(d.pos)?.let { (container, slot) ->
                        vm.moveItem(d.item.entity.id, container, slot)
                    }
                }
            },
        )
    }

    // Seret ke tepi layar untuk pindah halaman.
    val edge = drag?.let { d ->
        when {
            d.pos.x < screenWidth * 0.1f -> -1
            d.pos.x > screenWidth * 0.9f -> 1
            else -> 0
        }
    } ?: 0
    LaunchedEffect(edge) {
        while (edge != 0) {
            delay(700)
            val target = pager.currentPage + edge
            if (target !in 0 until LayoutConfig.PAGES) break
            pager.animateScrollToPage(target)
        }
    }

    Box(
        Modifier.fillMaxSize().systemBarsPadding()
            .onGloballyPositioned { rootOrigin = it.positionInRoot() }
            .onSizeChanged { screenWidth = it.width.toFloat() },
    ) {
        Column(
            Modifier.fillMaxSize().pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -120f) showDrawer = true },
                    onVerticalDrag = { _, delta -> total += delta },
                )
            },
        ) {
            HorizontalPager(
                state = pager,
                modifier = Modifier.weight(1f),
                userScrollEnabled = drag == null,
                beyondViewportPageCount = LayoutConfig.PAGES,
            ) { page ->
                PageGrid(
                    active = page == pager.currentPage,
                    items = state.items.filter {
                        it.entity.container == LayoutConfig.HOME && it.entity.page == page
                    },
                    bounds = homeBounds,
                    hover = hover?.takeIf {
                        it.first == LayoutConfig.HOME && it.second.page == page
                    }?.second,
                    draggingId = drag?.item?.entity?.id,
                    dragFor = dragFor,
                    onLaunch = vm::launch,
                    onUnpin = vm::unpin,
                    onInfo = vm::showInfo,
                )
            }
            PageIndicator(pager.currentPage, LayoutConfig.PAGES)
            Dock(
                items = state.items.filter { it.entity.container == LayoutConfig.DOCK },
                bounds = dockBounds,
                hoverCol = hover?.takeIf { it.first == LayoutConfig.DOCK }?.second?.col,
                draggingId = drag?.item?.entity?.id,
                dragFor = dragFor,
                onLaunch = vm::launch,
                onUnpin = vm::unpin,
                onInfo = vm::showInfo,
                onOpenDrawer = { showDrawer = true },
            )
        }

        AnimatedVisibility(
            visible = showDrawer,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            AppDrawer(
                apps = state.apps,
                onLaunch = { vm.launch(it); showDrawer = false },
                onPinHome = { vm.pin(it, LayoutConfig.HOME) },
                onPinDock = { vm.pin(it, LayoutConfig.DOCK) },
                onInfo = vm::showInfo,
                onPinAll = { vm.pinAllToHome(); showDrawer = false },
            )
        }

        // Ikon "hantu" yang mengikuti jari saat drag.
        drag?.let { d ->
            val half = with(androidx.compose.ui.platform.LocalDensity.current) { 28.dp.toPx() }
            Image(
                bitmap = d.item.app.icon,
                contentDescription = null,
                modifier = Modifier
                    .offset {
                        IntOffset(
                            (d.pos.x - rootOrigin.x - half).roundToInt(),
                            (d.pos.y - rootOrigin.y - half).roundToInt(),
                        )
                    }
                    .size(56.dp)
                    .graphicsLayer { scaleX = 1.2f; scaleY = 1.2f; alpha = 0.92f },
            )
        }
    }
}

@Composable
private fun PageGrid(
    active: Boolean,
    items: List<HomeItem>,
    bounds: MutableMap<Slot, Rect>,
    hover: Slot?,
    draggingId: Long?,
    dragFor: (HomeItem) -> DragHandler,
    onLaunch: (AppInfo) -> Unit,
    onUnpin: (Long) -> Unit,
    onInfo: (AppInfo) -> Unit,
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
        repeat(LayoutConfig.ROWS) { r ->
            Row(Modifier.weight(1f).fillMaxWidth()) {
                repeat(LayoutConfig.COLUMNS) { c ->
                    val highlighted = hover != null && hover.row == r && hover.col == c
                    Box(
                        Modifier.weight(1f).fillMaxHeight().padding(2.dp)
                            .onGloballyPositioned { if (active) bounds[Slot(0, r, c)] = it.boundsInRoot() }
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (highlighted) Color.White.copy(alpha = 0.2f) else Color.Transparent),
                        contentAlignment = Alignment.Center,
                    ) {
                        items.firstOrNull { it.entity.row == r && it.entity.col == c }?.let { item ->
                            AppIcon(
                                app = item.app,
                                labelColor = Color.White,
                                onClick = { onLaunch(item.app) },
                                drag = dragFor(item),
                                hidden = item.entity.id == draggingId,
                            ) { dismiss ->
                                DropdownMenuItem(
                                    text = { Text("Lepas dari Home") },
                                    onClick = { dismiss(); onUnpin(item.entity.id) },
                                )
                                DropdownMenuItem(
                                    text = { Text("Info aplikasi") },
                                    onClick = { dismiss(); onInfo(item.app) },
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PageIndicator(current: Int, count: Int) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Center,
    ) {
        repeat(count) { i ->
            Box(
                Modifier.padding(horizontal = 3.dp).size(if (i == current) 8.dp else 6.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = if (i == current) 0.95f else 0.45f)),
            )
        }
    }
}

@Composable
private fun Dock(
    items: List<HomeItem>,
    bounds: MutableMap<Slot, Rect>,
    hoverCol: Int?,
    draggingId: Long?,
    dragFor: (HomeItem) -> DragHandler,
    onLaunch: (AppInfo) -> Unit,
    onUnpin: (Long) -> Unit,
    onInfo: (AppInfo) -> Unit,
    onOpenDrawer: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Color.Black.copy(alpha = 0.28f))
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(LayoutConfig.DOCK_SLOTS) { c ->
            Box(
                Modifier.weight(1f).height(80.dp)
                    .onGloballyPositioned { bounds[Slot(0, 0, c)] = it.boundsInRoot() }
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (hoverCol == c) Color.White.copy(alpha = 0.2f) else Color.Transparent),
                contentAlignment = Alignment.Center,
            ) {
                items.firstOrNull { it.entity.col == c }?.let { item ->
                    AppIcon(
                        app = item.app,
                        labelColor = Color.White,
                        onClick = { onLaunch(item.app) },
                        drag = dragFor(item),
                        hidden = item.entity.id == draggingId,
                    ) { dismiss ->
                        DropdownMenuItem(
                            text = { Text("Lepas dari Dock") },
                            onClick = { dismiss(); onUnpin(item.entity.id) },
                        )
                        DropdownMenuItem(
                            text = { Text("Info aplikasi") },
                            onClick = { dismiss(); onInfo(item.app) },
                        )
                    }
                }
            }
        }
        Box(Modifier.weight(1f).height(80.dp), contentAlignment = Alignment.Center) {
            IconButton(onClick = onOpenDrawer) {
                Icon(Icons.Default.Menu, contentDescription = "Buka daftar aplikasi", tint = Color.White)
            }
        }
    }
}

@Composable
private fun AppDrawer(
    apps: List<AppInfo>,
    onLaunch: (AppInfo) -> Unit,
    onPinHome: (AppInfo) -> Unit,
    onPinDock: (AppInfo) -> Unit,
    onInfo: (AppInfo) -> Unit,
    onPinAll: () -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }
    Surface(
        Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background.copy(alpha = 0.97f),
    ) {
        Column(Modifier.padding(16.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Cari aplikasi") },
                singleLine = true,
                shape = RoundedCornerShape(24.dp),
            )
            TextButton(onClick = onPinAll) { Text("Pasang semua aplikasi ke Home") }
            Spacer(Modifier.height(4.dp))
            if (filtered.isEmpty()) {
                Text("Tidak ada aplikasi yang cocok", color = MaterialTheme.colorScheme.onBackground)
            }
            LazyVerticalGrid(GridCells.Adaptive(80.dp), Modifier.fillMaxSize()) {
                items(filtered, key = { it.key }) { app ->
                    AppIcon(
                        app = app,
                        labelColor = MaterialTheme.colorScheme.onBackground,
                        onClick = { onLaunch(app) },
                    ) { dismiss ->
                        DropdownMenuItem(
                            text = { Text("Pasang di Home") },
                            onClick = { dismiss(); onPinHome(app) },
                        )
                        DropdownMenuItem(
                            text = { Text("Pasang di Dock") },
                            onClick = { dismiss(); onPinDock(app) },
                        )
                        DropdownMenuItem(
                            text = { Text("Info aplikasi") },
                            onClick = { dismiss(); onInfo(app) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AppIcon(
    app: AppInfo,
    labelColor: Color,
    onClick: () -> Unit,
    drag: DragHandler? = null,
    hidden: Boolean = false,
    menu: @Composable (dismiss: () -> Unit) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    var origin by remember { mutableStateOf(Offset.Zero) }
    // Posisi lokal ikon diubah ke koordinat root; tekan lama tanpa geser membuka menu.
    val mapped = drag?.let { h ->
        DragHandler(
            start = { h.start(origin + it) },
            move = { h.move(origin + it) },
            end = { moved, canceled ->
                h.end(moved, canceled)
                if (!moved && !canceled) expanded = true
            },
        )
    }
    Box(Modifier.alpha(if (hidden) 0f else 1f)) {
        Column(
            Modifier.clip(RoundedCornerShape(16.dp))
                .onGloballyPositioned { origin = it.positionInRoot() }
                .iconGestures(app.key, onClick, { expanded = true }, mapped)
                .padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(56.dp))
            Text(
                text = app.label,
                color = labelColor,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = LocalTextStyle.current.copy(
                    shadow = if (labelColor == Color.White) {
                        Shadow(Color.Black.copy(alpha = 0.5f), blurRadius = 4f)
                    } else null,
                ),
            )
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            menu { expanded = false }
        }
    }
}

/**
 * Satu detektor untuk: ketuk, tekan lama (menu), dan tekan lama lalu seret (drag).
 * Geser sebelum waktu tekan lama dilepas ke parent (pager atau swipe ke drawer).
 */
@Composable
private fun Modifier.iconGestures(
    key: Any,
    onTap: () -> Unit,
    onLongPress: () -> Unit,
    drag: DragHandler?,
): Modifier {
    val tap by rememberUpdatedState(onTap)
    val longPress by rememberUpdatedState(onLongPress)
    val dragState by rememberUpdatedState(drag)
    return pointerInput(key) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            val slop = viewConfiguration.touchSlop
            val outcome = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                var r: Int? = null
                while (r == null) {
                    val change = awaitPointerEvent().changes.firstOrNull { it.id == down.id }
                    r = when {
                        change == null || change.isConsumed -> CANCEL
                        change.changedToUp() -> {
                            change.consume()
                            TAP
                        }
                        (change.position - down.position).getDistance() > slop -> CANCEL
                        else -> null
                    }
                }
                r
            }
            when (outcome) {
                TAP -> tap()
                null -> {
                    val handler = dragState
                    if (handler == null) {
                        longPress()
                        do {
                            val event = awaitPointerEvent()
                            event.changes.forEach { it.consume() }
                        } while (event.changes.any { it.pressed })
                    } else {
                        handler.start(down.position)
                        var moved = false
                        var finished = false
                        try {
                            while (true) {
                                val change = awaitPointerEvent().changes.firstOrNull { it.id == down.id }
                                if (change == null) {
                                    finished = true
                                    handler.end(true, true)
                                    break
                                }
                                change.consume()
                                if (!change.pressed) {
                                    finished = true
                                    handler.end(moved, false)
                                    break
                                }
                                if ((change.position - down.position).getDistance() > slop) moved = true
                                handler.move(change.position)
                            }
                        } finally {
                            if (!finished) handler.end(true, true)
                        }
                    }
                }
                else -> Unit
            }
        }
    }
}
