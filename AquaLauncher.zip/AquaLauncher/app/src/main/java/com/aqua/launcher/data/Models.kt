package com.aqua.launcher.data

import androidx.compose.ui.graphics.ImageBitmap

data class AppInfo(
    val packageName: String,
    val className: String,
    val label: String,
    val icon: ImageBitmap,
) {
    val key: String get() = "$packageName/$className"
}

/** Posisi logis (bukan piksel) agar layout tetap valid di semua ukuran layar. */
data class Slot(val page: Int, val row: Int, val col: Int)

object LayoutConfig {
    const val COLUMNS = 4
    const val ROWS = 5
    const val PAGES = 3
    const val DOCK_SLOTS = 4
    const val HOME = "HOME"
    const val DOCK = "DOCK"

    fun firstFreeSlot(container: String, occupied: Set<Slot>): Slot? {
        if (container == DOCK) {
            return (0 until DOCK_SLOTS).map { Slot(0, 0, it) }.firstOrNull { it !in occupied }
        }
        for (p in 0 until PAGES) for (r in 0 until ROWS) for (c in 0 until COLUMNS) {
            val s = Slot(p, r, c)
            if (s !in occupied) return s
        }
        return null
    }
}
