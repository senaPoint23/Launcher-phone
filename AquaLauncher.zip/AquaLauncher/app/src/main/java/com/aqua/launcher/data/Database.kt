package com.aqua.launcher.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.Transaction
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

/** Indeks unik pada slot mencegah dua ikon menempati posisi yang sama. */
@Entity(
    tableName = "home_items",
    indices = [Index(value = ["profileId", "container", "page", "row", "col"], unique = true)],
)
data class HomeItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: Long = 1,
    val container: String,
    val page: Int,
    val row: Int,
    val col: Int,
    val packageName: String,
    val className: String,
) {
    val key: String get() = "$packageName/$className"
    val slot: Slot get() = Slot(page, row, col)
}

@Dao
abstract class HomeItemDao {
    @Query("SELECT * FROM home_items WHERE profileId = :profileId")
    abstract fun observe(profileId: Long): Flow<List<HomeItemEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun insert(item: HomeItemEntity): Long

    @Query("DELETE FROM home_items WHERE id = :id")
    abstract suspend fun delete(id: Long)

    @Query("UPDATE home_items SET container = :container, page = :page, `row` = :row, col = :col WHERE id = :id")
    abstract suspend fun setSlot(id: Long, container: String, page: Int, row: Int, col: Int)

    /** Tukar posisi dua item secara atomik; slot sementara -1 menghindari tabrakan indeks unik. */
    @Transaction
    open suspend fun swap(a: HomeItemEntity, b: HomeItemEntity) {
        setSlot(a.id, a.container, -1, -1, -1)
        setSlot(b.id, a.container, a.page, a.row, a.col)
        setSlot(a.id, b.container, b.page, b.row, b.col)
    }
}

@Database(entities = [HomeItemEntity::class], version = 1, exportSchema = false)
abstract class AquaDatabase : RoomDatabase() {
    abstract fun homeItemDao(): HomeItemDao

    companion object {
        @Volatile private var instance: AquaDatabase? = null

        fun get(context: Context): AquaDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, AquaDatabase::class.java, "aqua.db",
            ).build().also { instance = it }
        }
    }
}
