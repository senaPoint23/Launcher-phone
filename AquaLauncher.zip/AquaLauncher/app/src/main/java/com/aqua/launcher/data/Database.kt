package com.aqua.launcher.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

/** Indeks unik pada slot mencegah dua ikon menempati posisi yang sama. */
@Entity(
    tableName = "home_items",
    indices = [Index(value = ["profileId", "container", "page", "row", "col"], unique = true)],
)
data class HomeItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: Long = 1,
    val container: String,
    val page: Int,
    val row: Int,
    val col: Int,
    val packageName: String,
    val className: String,
) {
    val key: String get() = "$packageName/$className"
    val slot: Slot get() = Slot(page, row, col)
}

@Dao
interface HomeItemDao {
    @Query("SELECT * FROM home_items WHERE profileId = :profileId")
    fun observe(profileId: Long): Flow<List<HomeItemEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(item: HomeItemEntity): Long

    @Query("DELETE FROM home_items WHERE id = :id")
    suspend fun delete(id: Long)
}

@Database(entities = [HomeItemEntity::class], version = 1, exportSchema = false)
abstract class AquaDatabase : RoomDatabase() {
    abstract fun homeItemDao(): HomeItemDao

    companion object {
        @Volatile private var instance: AquaDatabase? = null

        fun get(context: Context): AquaDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, AquaDatabase::class.java, "aqua.db",
            ).build().also { instance = it }
        }
    }
}
