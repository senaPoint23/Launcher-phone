package com.aqua.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.aqua.launcher.ui.AquaTheme
import com.aqua.launcher.ui.HomeScreen
import com.aqua.launcher.ui.HomeViewModel

class MainActivity : ComponentActivity() {
    private val vm: HomeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AquaTheme { HomeScreen(vm) } }
    }

    // Tombol Home ditekan saat launcher sudah terbuka: kembali ke halaman utama.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            vm.signalHome()
        }
    }
}
