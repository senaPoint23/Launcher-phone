package com.aqua.launcher

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.aqua.launcher.ui.AquaTheme
import com.aqua.launcher.ui.HomeScreen
import com.aqua.launcher.ui.HomeViewModel
import java.io.File

class MainActivity : ComponentActivity() {
    private val vm: HomeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Jika sesi sebelumnya crash, tampilkan laporan agar bisa disalin dan dikirim.
        val crashFile = File(filesDir, AquaApp.CRASH_FILE)
        if (crashFile.exists()) {
            showCrashReport(crashFile)
            return
        }

        enableEdgeToEdge()
        setContent { AquaTheme { HomeScreen(vm) } }
    }

    // Tombol Home ditekan saat launcher sudah terbuka: kembali ke halaman utama.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            vm.signalHome()
        }
    }

    private fun showCrashReport(file: File) {
        val report = file.readText()
        val copy = Button(this).apply {
            text = "Salin laporan crash"
            setOnClickListener {
                val clipboard = getSystemService(ClipboardManager::class.java)
                clipboard.setPrimaryClip(ClipData.newPlainText("crash", report))
                Toast.makeText(this@MainActivity, "Tersalin", Toast.LENGTH_SHORT).show()
            }
        }
        val retry = Button(this).apply {
            text = "Hapus laporan dan coba lagi"
            setOnClickListener { file.delete(); recreate() }
        }
        val body = TextView(this).apply {
            text = report
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(0xFFFFFFFF.toInt())
            setTextIsSelectable(true)
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
            addView(copy)
            addView(retry)
            addView(body)
        }
        setContentView(
            ScrollView(this).apply {
                setBackgroundColor(0xFF071A22.toInt())
                fitsSystemWindows = true
                addView(column)
            },
        )
    }
}
