package com.aqua.launcher.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aqua.launcher.data.AppInfo
import com.aqua.launcher.data.AppRepository
import com.aqua.launcher.data.AquaDatabase
import com.aqua.launcher.data.HomeItemEntity
import com.aqua.launcher.data.LayoutConfig
import com.aqua.launcher.data.Slot
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class HomeItem(val entity: HomeItemEntity, val app: AppInfo)

data class HomeUiState(
    val apps: List<AppInfo> = emptyList(),
    val items: List<HomeItem> = emptyList(),
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = AppRepository(application)
    private val dao = AquaDatabase.get(application).homeItemDao()

    val homeSignal = MutableStateFlow(0)
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 1)

    val state: StateFlow<HomeUiState> = combine(repo.observeApps(), dao.observe(PROFILE_ID)) { apps, rows ->
        val byKey = apps.associateBy { it.key }
        // Aplikasi yang sudah dihapus tidak boleh meninggalkan referensi rusak.
        if (apps.isNotEmpty()) {
            rows.filter { it.key !in byKey }.forEach { orphan ->
                viewModelScope.launch { dao.delete(orphan.id) }
            }
        }
        HomeUiState(apps, rows.mapNotNull { r -> byKey[r.key]?.let { HomeItem(r, it) } })
    }.stateIn(viewModelScope, SharingStarted.Eagerly, HomeUiState())

    fun signalHome() = homeSignal.update { it + 1 }
    fun launch(app: AppInfo) = repo.launch(app)
    fun showInfo(app: AppInfo) = repo.showInfo(app)

    fun pin(app: AppInfo, container: String) {
        viewModelScope.launch {
            val inContainer = state.value.items.filter { it.entity.container == container }
            if (inContainer.any { it.app.key == app.key }) {
                messages.tryEmit("Sudah ada di ${if (container == LayoutConfig.DOCK) "Dock" else "Home"}")
                return@launch
            }
            val slot = LayoutConfig.firstFreeSlot(container, inContainer.map { it.entity.slot }.toSet())
            if (slot == null) {
                messages.tryEmit("Tidak ada slot kosong")
                return@launch
            }
            dao.insert(
                HomeItemEntity(
                    container = container, page = slot.page, row = slot.row, col = slot.col,
                    packageName = app.packageName, className = app.className,
                ),
            )
        }
    }

    fun moveItem(itemId: Long, container: String, slot: Slot) {
        viewModelScope.launch {
            val all = state.value.items.map { it.entity }
            val me = all.firstOrNull { it.id == itemId } ?: return@launch
            if (me.container == container && me.slot == slot) return@launch
            val occupant = all.firstOrNull { it.container == container && it.slot == slot }
            if (occupant == null) {
                dao.setSlot(me.id, container, slot.page, slot.row, slot.col)
            } else {
                dao.swap(me, occupant)
            }
        }
    }

    fun pinAllToHome() {
        viewModelScope.launch {
            val st = state.value
            val homeItems = st.items.filter { it.entity.container == LayoutConfig.HOME }
            val occupied = homeItems.map { it.entity.slot }.toMutableSet()
            val pinned = homeItems.map { it.app.key }.toSet()
            var added = 0
            var skipped = 0
            for (app in st.apps) {
                if (app.key in pinned) continue
                val slot = LayoutConfig.firstFreeSlot(LayoutConfig.HOME, occupied)
                if (slot == null) {
                    skipped++
                    continue
                }
                occupied += slot
                dao.insert(
                    HomeItemEntity(
                        container = LayoutConfig.HOME, page = slot.page, row = slot.row, col = slot.col,
                        packageName = app.packageName, className = app.className,
                    ),
                )
                added++
            }
            messages.tryEmit(
                when {
                    added == 0 && skipped == 0 -> "Semua aplikasi sudah ada di Home"
                    skipped > 0 -> "$added aplikasi dipasang, $skipped tidak muat"
                    else -> "$added aplikasi dipasang"
                },
            )
        }
    }

    fun unpin(id: Long) {
        viewModelScope.launch { dao.delete(id) }
    }

    private companion object {
        const val PROFILE_ID = 1L
    }
}
