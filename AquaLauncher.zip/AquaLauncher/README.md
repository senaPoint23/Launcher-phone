# Aqua Launcher (fondasi v0.1)

Buka folder ini di Android Studio (Koala atau lebih baru), tunggu Gradle sync, lalu Run.
Setelah terpasang, tekan tombol Home dan pilih Aqua Launcher sebagai launcher default.

Sudah ada: terdaftar sebagai launcher (HOME), daftar aplikasi lewat LauncherApps dengan update otomatis,
App Drawer dengan pencarian, Home 3 halaman (grid 4x5) dan Dock, pasang/lepas ikon lewat tekan lama,
penyimpanan posisi logis di Room (indeks unik mencegah ikon bertumpuk), wallpaper sistem, tema terang/gelap.

Baru di 0.2.0: drag-and-drop ikon (Home, Dock, antarhalaman, tukar posisi) dan tombol Pasang semua aplikasi ke Home.

Belum ada: folder, widget, custom icon, profil, template, tema AMOLED.
